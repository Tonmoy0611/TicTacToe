
package Package2;

import javax.swing.JFrame;

public class Test1 extends JFrame {
    
    Test1(){
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(50,100, 400, 500);
        setTitle("This is Title");
        setTitle("It is me, who is a losser");
        setResizable(false);
    }
    
    
    public static void main(String[] args) {
        
        Test1 frame = new Test1();
        
        frame.setVisible(true);
        
    }
    
}
