
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


public class Multiplication extends JFrame {
    
    private Container c;
    private JLabel imgLabel, textLabel;
    private JTextArea ta;
    private JTextField tf;
    private JButton btn;
    private ImageIcon img, img2;
    private Font f,f1;
    private Cursor csr;
    private ImageIcon icon;
    
    Multiplication(){
        initComponents();
    }
    
    public void initComponents(){
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        f = new Font("Tahoma", Font.BOLD, 28);
        f1 = new Font("Tahoma", Font.BOLD, 31);
        
        img2 = new ImageIcon(getClass().getResource("clear.png"));
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        img  = new ImageIcon(getClass().getResource("hqdefault.jpg"));
        imgLabel = new JLabel(img);
        imgLabel.setBounds(11, 10,img.getIconWidth(), img.getIconHeight());
        c.add(imgLabel);
        
        textLabel = new JLabel("Enter any number: ");
        textLabel.setBounds(60, 347,320, 60);
        textLabel.setForeground(Color.MAGENTA);
        textLabel.setFont(f);
        c.add(textLabel);
        
        csr = new Cursor(Cursor.HAND_CURSOR);
        
        tf = new JTextField();
        tf.setBounds(340, 350, 130, 65);
        tf.setBackground(Color.GREEN);
        tf.setFont(f1);
        tf.setHorizontalAlignment(JTextField.CENTER);
        c.add(tf);
        
        btn = new JButton(img2);
        btn.setBounds(340, 420, 130, 65);
        btn.setCursor(csr);
        c.add(btn);
        
        ta = new JTextArea(); 
        ta.setBounds(20,520, 480, 365);
        ta.setFont(f);
        
        ta.setBackground(Color.GREEN);
        c.add(ta);
        
        tf.addActionListener(new ActionListener(){
            
            
            
            public void actionPerformed(ActionEvent e){
                
                String value = tf.getText();
                if (value.isEmpty()) {
                    JOptionPane.showMessageDialog(null," You haven't put any number");
                }
                
                else{
                    ta.setText("");
                
                int n =Integer.parseInt(tf.getText());
                
                for (int i = 1; i <= 10; i++) {
                    int r = n*i;
                    String ra = String.valueOf(r);
                    String na = String.valueOf(n);
                    String ia = String.valueOf(i);
                    
                    ta.append(na+" X "+ia+" = "+ra+"\n");
                    }
                }
                
            }
            
        });
        
        btn.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ae) {
                 
                ta.setText("");
                tf.setText("");
                
            }
            
        });
        
        
    }
    
    
    public static void main(String[] args) {
        Multiplication frame = new Multiplication();
        frame.setVisible(true);
        frame.setBounds(300, 20, 535,950);
        frame.setTitle("Multiplication Table");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
} 
