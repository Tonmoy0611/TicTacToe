
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class VowelCounter extends JFrame {
    
    private Container c;
    private JLabel pl,vlb, alb, elb, ilb, olb, ulb;
    private JTextArea ta;
    private JScrollPane scroll;
    private ImageIcon icon;
    private Font f;
    
    int total_v = 0;
    int n_a = 0, n_e = 0, n_i=0, n_o=0, n_u=0;
    
    VowelCounter()
    {
        initComponents();
    }
    
    public void initComponents(){
    
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100, 100, 600, 500);
        this.setTitle("Vowel Counter");
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        f = new Font("Tahoma", Font.BOLD, 20);
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        pl = new JLabel("Enter your Text : ");
        pl.setBounds(10, 20, 100, 30);
        c.add(pl);
        
        ta = new JTextArea();
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        ta.setFont(f);
        c.add(ta);
        
        scroll = new JScrollPane(ta);
        scroll.setBounds(110, 20, 450,100);
        c.add(scroll);
        
        vlb = new JLabel();
        vlb.setBounds(110, 150, 250, 30);
        c.add(vlb);
        
        alb = new JLabel();
        alb.setBounds(110, 190, 150, 30);
        c.add(alb);
        
        elb = new JLabel();
        elb.setBounds(110, 230, 150, 30);
        c.add(elb);
        
        ilb = new JLabel();
        ilb.setBounds(110, 270, 150, 30);
        c.add(ilb);
        
        olb = new JLabel();
        olb.setBounds(110, 310, 150, 30);
        c.add(olb);
        
        ulb = new JLabel();
        ulb.setBounds(110, 350, 150, 30);
        c.add(ulb);
        
        ta.addKeyListener(new KeyListener(){

            @Override
            public void keyTyped(KeyEvent ke) {
                
            }

            @Override
            public void keyPressed(KeyEvent ke) {
                
                if (ke.getSource() == ta) {
                    
                    if (ke.VK_A==ke.getKeyCode()) {
                        
                        n_a++;
                        total_v++;
                    }
                    if (ke.VK_E==ke.getKeyCode()) {
                        
                        n_e++;
                        total_v++;
                    }
                    if (ke.VK_I==ke.getKeyCode()) {
                        
                        n_i++;
                        total_v++;
                    }
                    if (ke.VK_O==ke.getKeyCode()) {
                        
                        n_o++;
                        total_v++;
                    }
                    if (ke.VK_U==ke.getKeyCode()) {
                        
                        n_u++;
                        total_v++;
                    }
                }
                
                vlb.setText("Total number of vowel = "+total_v);
                alb.setText("Total number of  a = "+n_a);
                elb.setText("Total number of  e = "+n_e);
                ilb.setText("Total number of  i = "+n_i);
                olb.setText("Total number of  o = "+n_o);
                ulb.setText("Total number of  u = "+n_u);
            }

            @Override
            public void keyReleased(KeyEvent ke) {
                
            }
        
            
        });
    }
    
    public static void main(String[] args) {
        
        VowelCounter frame = new VowelCounter();
        frame.setVisible(true);
    }
    
}
