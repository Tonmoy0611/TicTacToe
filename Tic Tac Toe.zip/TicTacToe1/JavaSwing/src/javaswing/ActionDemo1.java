
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class ActionDemo1 extends JFrame{
    
    private Container c;
    private JTextField tf1, tf2;
    private ImageIcon icon;
    
    ActionDemo1(){
        initComponents();
    }
    
    public void initComponents(){
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        tf1 = new JTextField();
        tf1.setBounds(50, 50, 150, 50);
        c.add(tf1);
        
        tf2 = new JTextField();
        tf2.setBounds(50, 110, 150, 50);
        c.add(tf2);
        
        Handler hand = new Handler();
        tf1.addActionListener(hand);
        tf2.addActionListener(hand);
        }
    
        class Handler implements ActionListener{
            public void actionPerformed(ActionEvent e){
                
                if(e.getSource()==tf1){
                    String s = tf1.getText();
                if(s.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "The box is empty... \n Please enter any text ");
                }
                else{
                                    
                JOptionPane.showMessageDialog(null, "tf1 = "+s);
                }
                }
                else{
                    String s = tf2.getText();
                if(s.isEmpty())
                {
                    JOptionPane.showMessageDialog(null, "The box is empty... \n Please enter any text ");
                }
                else{
                                    
                JOptionPane.showMessageDialog(null, "tf2 = "+s);
                }
                }
                    
                
            }
        }
    
    
    public static void main(String[] args) {
        ActionDemo1 frame = new ActionDemo1();      
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(1400,50, 500, 400);
        frame.setTitle("Action Listener demo");
    }
    
}
