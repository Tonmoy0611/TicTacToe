
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JTextField;


public class TextFieldDemo extends JFrame {
    
    private Container c;
    private JTextField  tf1, tf2;
    private Font f;
    private ImageIcon icon;
    
    TextFieldDemo(){
         initComponents();
    }
    
    public void initComponents(){
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        f = new Font("Arial",Font.ITALIC + Font.BOLD, 20);
        
        tf1 = new JTextField();
        //tf1.setText("This is your text");
        tf1.setBounds(85,50, 200, 50);
        tf1.setFont(f);
        tf1.setForeground(Color.black);
        tf1.setBackground(Color.LIGHT_GRAY);
        tf1.setHorizontalAlignment(JTextField.LEFT);
        c.add(tf1);
        
        tf2 = new JTextField();
        //tf2.setText("This is your text");
        tf2.setBounds(85,110,200,50);
        tf2.setFont(f);
        tf2.setForeground(Color.BLACK);
        tf2.setBackground(Color.LIGHT_GRAY);
        c.add(tf2);       
    }
    
    public static void main(String[] args) {
        
        TextFieldDemo frame = new TextFieldDemo();      
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(1500,50, 400, 500);
        frame.setTitle("JText field demo");
        
         
    }
    
}
