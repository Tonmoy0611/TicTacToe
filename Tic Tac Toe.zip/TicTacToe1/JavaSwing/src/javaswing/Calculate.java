
package javaswing;

import javax.swing.JOptionPane;

public class Calculate {
    double x, y;
    
     Calculate(double a, double b){
        x = a;
        y = b;
    }
    
    public double Add() {
      return (x + y); 
    }

    public double Sub() {
          if(x>y)
              return (x - y);
         else
              return(y-x);
    } 

    public double Mul() {
      return (x * y);
    }

    public double Div() {
      return (x / y);
    }

    public static void main(String[] args) {
    
    String input;
    double a, b,z;
    char c;
    
        input = JOptionPane.showInputDialog("Enter First number");
        a=Double.parseDouble(input);  
      
        input = JOptionPane.showInputDialog("Operation symbol :");
        c=input.charAt(0);

        input = JOptionPane.showInputDialog("Enter Secnod number");
        b=Double.parseDouble(input);  
      

            
    Calculate Obj = new Calculate(a,b);
    
    if(c == '+'){
         z = Obj.Add();
        JOptionPane.showMessageDialog(null,"Sum is = "+z,"Result", JOptionPane.PLAIN_MESSAGE);
    }
    else if(c == '-'){
         z = Obj.Sub();
        JOptionPane.showMessageDialog(null,"Sub is = "+z,"Result", JOptionPane.PLAIN_MESSAGE);
    }
    else if(c == '*'){
         z = Obj.Mul();
        JOptionPane.showMessageDialog(null,"Mul is = "+z,"Result", JOptionPane.PLAIN_MESSAGE);
    }
    else if(c == '/'){
         z = Obj.Div();
        JOptionPane.showMessageDialog(null,"Div is = "+z,"Result", JOptionPane.PLAIN_MESSAGE);
    }
        
  }
    
}
