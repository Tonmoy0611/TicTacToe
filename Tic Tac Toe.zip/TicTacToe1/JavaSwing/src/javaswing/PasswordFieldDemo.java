
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPasswordField;


public class PasswordFieldDemo extends JFrame {
    
    private Container c;
    private JPasswordField pf;
    private Font f;
    private ImageIcon icon;
    
    PasswordFieldDemo(){
        initComponents();
        
    }
    
    public void initComponents(){
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        f = new Font("Arial",Font.BOLD,30);
        
        pf = new JPasswordField();
        pf.setEchoChar('*');
        pf.setFont(f);
        pf.setBounds(50,20,150,50);
        pf.setForeground(Color.BLACK);
        pf.setBackground(Color.LIGHT_GRAY);
        c.add(pf);
       
    }
    
    public static void main(String[] args) {
        PasswordFieldDemo frame = new PasswordFieldDemo();      
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(1400,50, 500, 400);
        frame.setTitle("JPasswordField");
    }
    
}
