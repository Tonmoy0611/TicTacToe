
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class NewFrame extends JFrame {
    
        private Container c;
        private JLabel lbl1, lbl2;
        private Font f;
        private ImageIcon icon;
    
    NewFrame(){
        
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        this.setBounds(750, 100, 500, 400);
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        f = new Font("Arial",Font.BOLD,24); 
        
        lbl1 = new JLabel("Secret Key : ");
        lbl1.setBounds(60, 50, 540, 50);
        lbl1.setFont(f);
        c.add(lbl1);
        
        lbl2 = new JLabel("-> yz9RrNPKkDKNWgf");
        lbl2.setBounds(60, 80, 540, 50);
        lbl2.setFont(f);
        c.add(lbl2);
        
    }
    
    public static void main(String[] args) {
        
        NewFrame frame = new NewFrame();
        frame.setVisible(true);
    }
    
}
