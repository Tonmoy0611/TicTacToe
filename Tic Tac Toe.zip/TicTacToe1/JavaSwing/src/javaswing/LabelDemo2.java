
package javaswing;

import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class LabelDemo2 extends JFrame {
    
    private Container c;
    private JLabel imgLabel;
    private ImageIcon img;
    private ImageIcon icon;
    
    LabelDemo2(){
        initComponents();
    }
    
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        img = new ImageIcon(getClass().getResource("mpsr.jpg"));
        
        imgLabel = new JLabel(img);
        imgLabel.setBounds(80, 70, img.getIconWidth(), img.getIconHeight());
        c.add(imgLabel);
    }
    
    public static void main(String[] args) {
        
        LabelDemo2 frame = new LabelDemo2();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200, 50, 500, 500);

        frame.setTitle("This is Totally faltu");
        
    }
}
