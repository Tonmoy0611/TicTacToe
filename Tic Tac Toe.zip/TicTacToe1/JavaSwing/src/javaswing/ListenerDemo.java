
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;


public class ListenerDemo extends JFrame implements ActionListener {
    
    private Container c;
    private JButton btn1, btn2, btn3;
    private ImageIcon icon;
    private Font f;
    
    ListenerDemo(){
    
        initComponents();
    }
    
    public void initComponents(){
    
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100, 100, 600, 500);
        this.setTitle("Listener Demo");
        
        c = this.getContentPane();
        c.setBackground(Color.LIGHT_GRAY);
        c.setLayout(null);
        
        f = new Font("Tahoma", Font.BOLD, 18);
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        btn1 = new JButton("R E D");
        btn1.setBounds(50, 50, 100, 50);
        c.add(btn1);
        
        btn2 = new JButton("B L U E");
        btn2.setBounds(50, 120, 100, 50);
        c.add(btn2);
        
        btn3 = new JButton("GREEN");
        btn3.setBounds(50, 190, 100, 50);
        c.add(btn3);
        
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        
        
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource()==btn1) {
            c.setBackground(Color.RED);
        }
        
        else if (e.getSource()==btn2) {
            c.setBackground(Color.BLUE);
        }
        else if(e.getSource()==btn3){
             c.setBackground(Color.GREEN);
        }
        
    }
    
    
    public static void main(String[] args) {
        
        ListenerDemo frame = new ListenerDemo();
        frame.setVisible(true);
        
        
    }

    
    
}
