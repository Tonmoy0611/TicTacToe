
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

public class ActionDemo2 extends JFrame{
    
    private Container c;
    private JTextField tf;
    private JButton btn;
    private ImageIcon img1;
    private Font f;
    private ImageIcon icon;
    
    ActionDemo2(){
        initComponents();
    }
    
    public void initComponents(){
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        img1 = new ImageIcon(getClass().getResource("clear.png"));
        f = new Font("Arial",Font.BOLD,30);
        
        tf = new JTextField();
        tf.setBounds(150, 50, 200, 60);
        tf.setFont(f);
        c.add(tf);
        
        btn = new JButton(img1);
        btn.setBounds(186, 150, 130, 65);
        c.add(btn);
        btn.addActionListener(new ActionListener(){
            
            public void actionPerformed(ActionEvent e){
                tf.setText("");
            }
        });
        
    }
        public static void main(String[] args) {
        ActionDemo2 frame = new ActionDemo2();      
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(1400,50, 500, 400);
        frame.setTitle("Action listener Demo 2");
    }
}
