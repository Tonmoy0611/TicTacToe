
package javaswing;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import java.awt.Container;

public class FrameDemo extends JFrame{
    
    private ImageIcon icon;
    private Container c;
    
    FrameDemo(){
        
        initComponents();
    }
    
    public void initComponents(){
        
        c = this.getContentPane();
        c.setBackground(Color.green);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
    }
    
    
    public static void main(String[] args) {
        
        FrameDemo frame = new FrameDemo();
        
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //frame.setSize(400, 300);
        //frame.setLocationRelativeTo(null);//set in middle
        //frame.setLocation(1400, 100);
        
        frame.setBounds(1400, 100, 400, 300);//Combine of setSize and setLocation
        frame.setTitle("It is me, who is a losser");
        frame.setResizable(false);
               
    }
}
