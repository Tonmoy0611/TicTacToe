
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class LoginFrame extends JFrame {
    
    private Container c;
    private JLabel ul, pl;
    private JTextField tf;
    private JPasswordField pf;
    private JButton btn1,btn2;
    private Font f;
    private ImageIcon icon;
    private ImageIcon img1,img2;
    
    LoginFrame(){
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(1400,100, 500, 400);
        this.setTitle("Log in Frame");
        
        c =this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        f = new Font("Arial",Font.BOLD,24); 
        img1 = new ImageIcon(getClass().getResource("login.png"));
        img2 = new ImageIcon(getClass().getResource("clear.png"));
        
        ul = new JLabel("Username : ");
        ul.setFont(f);
        ul.setBounds(60,50, 150, 50);
        c.add(ul);
        
        tf = new JTextField();
        tf.setBounds(190,50, 200, 50);
        tf.setFont(f);
        c.add(tf);
        
        pl = new JLabel("Password : ");
        pl.setFont(f);
        pl.setBounds(60, 120, 150, 50);
        c.add(pl);
        
        pf = new JPasswordField();
        pf.setBounds(190,120, 200, 50);
        pf.setEchoChar('*');
        pf.setFont(f);
        c.add(pf);
        
        
        btn1 = new JButton(img1);
        btn1.setBounds(60, 210, 130, 65);
        c.add(btn1);
        
        
        btn2 = new JButton(img2);
        btn2.setBounds(260, 210, 130, 65);
        c.add(btn2);
        
        btn1.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent ae) {
               String userName = tf.getText();
               String pass = pf.getText();
               
               if(userName.equals("shourov") && pass.equals("123"))
               {
                   JOptionPane.showMessageDialog(null, "Welcome \nYou are Successfully logged in");
                   
                   NewFrame frame = new NewFrame();
                   frame.setVisible(true);
               }
               else
               {
                   JOptionPane.showMessageDialog(null, "Sorry!!! \nInvalid Username or password");
               }
            }
            
        });
        
        btn2.addActionListener(new ActionListener(){
            
            @Override
            public void actionPerformed(ActionEvent ae){
                tf.setText("");
                pf.setText("");
            }
        });
    }
    
    public static void main(String[] args) {
        LoginFrame frame = new LoginFrame();      
        frame.setVisible(true);
    }
    
}
