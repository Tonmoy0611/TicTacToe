
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class LabelDemo extends JFrame {
    
    private Container c;
    private JLabel ul, pl;
    private Font f;
    
    LabelDemo(){
        initComponents();
    }
    
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        f = new Font("Arial", Font.BOLD,14);
        
        ul = new JLabel();
        ul.setText("Enter Your user name: ");
        ul.setBounds(50, 20,200,50);
        ul.setFont(f);
        ul.setForeground(Color.RED);
        ul.setOpaque(true);
        ul.setBackground(Color.yellow);
        ul.setToolTipText("Tghis is a tool tip text");
        c.add(ul);
        
        //System.out.println(" "+ul.getText()); //Component e ki set kora ache ta dekha jabe
        
        String s = ul.getToolTipText();
        System.out.println(" "+s);
        
        pl = new JLabel();
        pl.setText("Enter your password: ");
        pl.setBounds(50,70, 200, 50);
        c.add(pl);
        pl.setFont(f);
    }
    
    public static void main(String[] args) {
        
        LabelDemo frame = new LabelDemo();
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(200, 50, 600, 400);

        frame.setTitle("This is Totally faltu");
        
    }
}
