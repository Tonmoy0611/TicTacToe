
package javaswing;


import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class ComboBoxDemo extends JFrame {
    
    private Container c;
    private JComboBox cb;
    private String[] proLang = {"C", "C++"," JAVA","PHP", "PYTHON"};
    private JLabel lbl;
    private ImageIcon icon;
    private Font f;
    private JButton btn;
    private ImageIcon img1,img2;
    
    ComboBoxDemo(){
    
        initComponents();
    }
    
    public void initComponents(){
        
         this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         this.setBounds(100, 100, 500, 400);
         this.setTitle("ComboBox Demo");
         
         c = this.getContentPane();
         c.setLayout(null);
         c.setBackground(Color.PINK);
         
        f = new Font("Tahoma", Font.BOLD, 18);
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        img1 = new ImageIcon(getClass().getResource("login.png"));
        img2 = new ImageIcon(getClass().getResource("OK.png"));
         
         cb = new JComboBox(proLang);
         cb.setBounds(80, 30, 100, 50);
         cb.setEditable(true);
         //cb.setSelectedIndex(4);
         //cb.setSelectedItem("JAVA");
         cb.addItem("FORTRAN");
         cb.addItem("BASIC");
         //cb.removeItem("FORTRAN");
         cb.removeItemAt(5);
         //cb.removeAllItems();
         c.add(cb);
         
         //System.out.println("Total item = "+cb.getItemCount());
         
        btn = new JButton(img2);
        btn.setBounds(210, 30,130, 65);
        c.add(btn);
         
         lbl = new JLabel();
         lbl.setBounds(80, 200, 300, 50);
         lbl.setBackground(Color.PINK);
         lbl.setFont(f);
         c.add(lbl);
         
         btn.addActionListener(new ActionListener(){

             @Override
             public void actionPerformed(ActionEvent ae) {
               
                 
                 String s = cb.getSelectedItem().toString();
                 lbl.setText("You have selected : "+s);
             }
         });
    }
    
    public static void main(String[] args) {
         
        ComboBoxDemo frame = new ComboBoxDemo();
        frame.setVisible(true);
    }
}




