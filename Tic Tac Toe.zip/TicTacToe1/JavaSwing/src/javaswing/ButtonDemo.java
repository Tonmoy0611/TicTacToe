
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;

public class ButtonDemo extends JFrame {
    
   
    private Container c;
    private JButton btn1, btn2;
    private ImageIcon img1,img2;
    private Font f;
    private Cursor csr;
    private ImageIcon icon; 
     
    ButtonDemo(){
        initComponents();
    }
    
    public void initComponents(){
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.pink);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        f = new Font("Arial",Font.BOLD,18);
        csr = new Cursor(Cursor.HAND_CURSOR);
        
        img1 = new ImageIcon(getClass().getResource("Ok.png"));
        img2 = new ImageIcon(getClass().getResource("clear.png"));
        
        btn1 = new JButton(img1);
        btn1.setBounds(100, 50, 130, 65);
        //btn1.setFont(f);
        //btn1.setForeground(Color.WHITE);
        //btn1.setBackground(Color.BLACK);
        btn1.setCursor(csr);
        c.add(btn1);
        
        btn2 = new JButton(img2);
        btn2.setBounds(250, 50, 130, 65);
        //btn2.setFont(f);
        //btn2.setForeground(Color.WHITE);
        //btn2.setBackground(Color.BLACK);
        btn2.setCursor(csr); 
        c.add(btn2);
    }
    
    public static void main(String[] args) {
        ButtonDemo frame = new ButtonDemo();      
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(1400,50, 500, 400);
        frame.setTitle("JButton Demo");
    }
    
}
