
package javaswing;

import javax.swing.JOptionPane;

public class MassegeDialogue {
    public static void main(String[] args) {
        
        
        JOptionPane.showMessageDialog(null," is = ","LOOK AT ME", JOptionPane.PLAIN_MESSAGE);
        JOptionPane.showMessageDialog(null," is = ","Result", JOptionPane.PLAIN_MESSAGE);
        
    }
    
}
