
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class TextAreaDemo extends JFrame {
    
    private Container c;
    private JTextArea ta;
    private Font f;
    private ImageIcon icon;
    private JScrollPane scroll;
    
    TextAreaDemo()
    {
        initComponents();
    }
    
    public void initComponents()
    {
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        
        f = new Font("Arial",Font.BOLD,20); 
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        ta = new JTextArea();
        ta.setForeground(Color.YELLOW);
        ta.setBackground(Color.GRAY);
        ta.setFont(f);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        
        scroll = new JScrollPane(ta,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scroll.setBounds(50, 50, 300, 200);
        c.add(scroll);
    }
    
    public static void main(String[] args) {
        
        TextAreaDemo frame = new TextAreaDemo();
        frame.setVisible(true);
        frame.setBounds(100, 50, 500, 400);
        frame.setTitle("TextArea Demo");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
            
    }
}
    

