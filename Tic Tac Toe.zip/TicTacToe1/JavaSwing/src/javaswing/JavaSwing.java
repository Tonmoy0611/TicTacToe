
package javaswing;


public class JavaSwing {

    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
