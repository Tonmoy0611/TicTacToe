
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;


public class CheckBoxDemo extends JFrame {
    
    private Container c;
    private JCheckBox ckb, jckb, ickb;
    private Font f;
    private ButtonGroup gp;
    private ImageIcon icon;
    private JLabel lbl;
    
    CheckBoxDemo(){
    
        initComponents();
    }
    
    public void initComponents(){
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(200, 100, 500, 400);
        this.setTitle("CheakBox demo");
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.PINK);
        
        f = new Font("Tahoma", Font.BOLD, 21);
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        gp = new ButtonGroup();
        
        ckb = new JCheckBox("Katrina");
        ckb.setBounds(50, 100,250, 30);
        ckb.setBackground(Color.PINK);
        //ckb.setSelected(true);
        ckb.setFont(f);
        c.add(ckb);
        
        jckb = new JCheckBox("Dipika");
        jckb.setBounds(50, 150,250, 30);
        jckb.setBackground(Color.PINK);
        jckb.setFont(f);
        c.add(jckb);
        
        ickb = new JCheckBox("Alia");
        ickb.setBounds(50, 200,250, 30);
        ickb.setBackground(Color.PINK);
        ickb.setFont(f);
        c.add(ickb);
        
        gp.add(ckb);
        gp.add(jckb);
        gp.add(ickb);
        
        lbl = new JLabel("Select any one among them");
        lbl.setBounds(60,240,350,60);
        lbl.setFont(f);
        c.add(lbl);
        
        Handler handler = new Handler();
        ckb.addActionListener(handler);
        jckb.addActionListener(handler);
        ickb.addActionListener(handler);
    }
    
    class Handler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent ae) {
            
            if(ckb.isSelected())
            {
                lbl.setText("You have selected Katrina Kaif");
            }
            else if(jckb.isSelected())
            {
                lbl.setText("You have selected Dipika Parkun");
            }
            else
            {
                lbl.setText("You have selected Alia Bhatt");
            }
            
        }
        
        
    }
    
    public static void main(String[] args) {
        
        CheckBoxDemo frame = new CheckBoxDemo();
        frame.setVisible(true);
    }
    
}
