
package javaswing;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javaswing.ActionDemo1.Handler;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class RadioButton extends JFrame {
    
    private Container c;
    private JRadioButton male, female;
    private Font f;
    private ButtonGroup gp;
    private JTextArea ta;
    private ImageIcon icon;
    private JScrollPane scroll;
    
    RadioButton(){
        initComponents();
    }
    
    public void initComponents(){
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setBounds(100, 50, 400, 400);
        this.setTitle("Radio Button");
        
        f = new Font("Tahoma", Font.BOLD, 21);
        
        icon = new ImageIcon(getClass().getResource("Miscellaneous-Icon.jpg"));
        this.setIconImage(icon.getImage());
        
        c = this.getContentPane();
        c.setLayout(null);
        c.setBackground(Color.ORANGE);
        
        gp = new ButtonGroup();
        
        male = new JRadioButton("Male");
        male.setBounds(50, 50 ,100, 50);
        male.setBackground(Color.ORANGE);
        male.setSelected(true);
        male.setFont(f);
        c.add(male);
        
        female = new JRadioButton("Female");
        female.setBounds(200, 50 ,120, 50);
        female.setBackground(Color.ORANGE);
        female.setFont(f);
        //female.setEnabled(false);
        c.add(female);
        
        gp.add(male);
        gp.add(female);
        
        ta = new JTextArea();
        ta.setBounds(20, 110, 340, 200);
        ta.setFont(f);
        ta.setBackground(Color.LIGHT_GRAY);
        c.add(ta);
        
        
        scroll = new JScrollPane(ta,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
        scroll.setBounds(50, 110, 300, 200);
        c.add(scroll);
        
        Handler handler = new Handler();
        male.addActionListener(handler);
        female.addActionListener(handler);
        
    }
    
    class Handler implements ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            if (male.isSelected()) {
                
                ta.append("You have selected male\n");
            }
            else{
                
                ta.append("You have selected Female\n");
            }
            
        }
        
    
    }
    
    public static void main(String[] args) {
        
        RadioButton frame = new RadioButton();
        frame.setVisible(true);
    }
    
}
